"""
flowguard/api/main.py
─────────────────────
FastAPI application.

ENDPOINT MAP
════════════
POST /parse
    IN : NLPParseRequest  { raw_text, language, context? }
    OUT: ScoreRequest     { obligations[], cash_position }

POST /score
    IN : ScoreRequest     { obligations[], cash_position, scenario_label? }
    OUT: EngineResult     { decisions[], days_to_zero, summary_narrative, ... }

POST /narrate
    IN : NLPNarrateRequest { engine_result, output_language, channel }
    OUT: NarrateResponse   { text, whatsapp_preview }

POST /pipeline
    IN : NLPParseRequest   (same as /parse)
    OUT: PipelineResponse  { score_request, engine_result, narrative }
    ↑ This is the ONE-SHOT endpoint for WhatsApp bots.
      Human text IN → full narrated result OUT.

GET  /health
    OUT: { status, engine_version, spacy_available, st_available }

POST /email
    IN : EmailRequest      { decision_id, engine_result, sender_name, proposed_date? }
    OUT: EmailResponse     { subject, body, tone }

POST /whatif
    IN : WhatIfRequest     { base_score_request, what_if_text }
    OUT: WhatIfResponse    { original, modified, delta_narrative }

POST /audit/{run_id}
    IN : run_id (path param)
    OUT: AuditEntry        { input_hash, decisions_hashes[], computed_at }

Run with:
    uvicorn flowguard.api.main:app --host 0.0.0.0 --port 8000 --reload
"""

from __future__ import annotations

import hashlib
import json
import logging
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

# Project root for serving static files
_PROJECT_ROOT = Path(__file__).resolve().parent.parent

from .models import (
    ActionTag,
    CashPosition,
    DecisionRecord,
    EngineResult,
    NLPNarrateRequest,
    NLPParseRequest,
    Obligation,
    ObligationCategory,
    ScoreRequest,
)
from .scorer import run_engine
from .parser import (
    ST_AVAILABLE,
    SPACY_AVAILABLE,
    classify_intent,
    draft_negotiation_email,
    extract_what_if_params,
    narrate_result,
    narrate_whatsapp_preview,
    parse_text_to_obligations,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

ENGINE_VERSION = "1.1.0"

# ─────────────────────────────────────────────
# Audit Store (abstracted for PostgreSQL migration)
# ─────────────────────────────────────────────

from abc import ABC, abstractmethod


class AuditStore(ABC):
    """Abstract audit store. Swap InMemoryAuditStore for PostgresAuditStore in prod."""

    @abstractmethod
    def store(self, run_id: str, entry: dict) -> None: ...

    @abstractmethod
    def get(self, run_id: str) -> Optional[dict]: ...

    @abstractmethod
    def list_ids(self) -> list[str]: ...


class InMemoryAuditStore(AuditStore):
    def __init__(self) -> None:
        self._store: dict[str, dict] = {}

    def store(self, run_id: str, entry: dict) -> None:
        self._store[run_id] = entry

    def get(self, run_id: str) -> Optional[dict]:
        return self._store.get(run_id)

    def list_ids(self) -> list[str]:
        return list(self._store.keys())


_audit_store = InMemoryAuditStore()


# ─────────────────────────────────────────────
# EXTRA REQUEST / RESPONSE MODELS
# ─────────────────────────────────────────────

class NarrateResponse(BaseModel):
    text: str
    whatsapp_preview: str


class PipelineResponse(BaseModel):
    """One-shot: raw text → full narrated result (for WhatsApp bot)."""
    intent: str
    score_request: ScoreRequest
    engine_result: EngineResult
    narrative: str
    whatsapp_preview: str


class EmailRequest(BaseModel):
    decision_index: int = Field(
        ..., description="Index into engine_result.decisions list (0-based)."
    )
    engine_result: EngineResult
    sender_name: str = Field("The Management")
    proposed_date: Optional[date] = Field(None)


class EmailResponse(BaseModel):
    subject: str
    body: str
    tone: str


class WhatIfRequest(BaseModel):
    """
    Scenario analysis.
    Modifies the cash_position (adds an expected inflow) then re-runs the engine.
    """
    base_score_request: ScoreRequest
    what_if_text: str = Field(
        ...,
        description="Natural language what-if. "
                    "E.g. 'What if Kapoor pays me 30000 tomorrow?'"
    )


class WhatIfResponse(BaseModel):
    what_if_text: str
    extracted_params: dict
    original_result: EngineResult
    modified_result: EngineResult
    delta_narrative: str


class AuditEntry(BaseModel):
    run_id: str
    input_hash: str
    computed_at: datetime
    obligation_count: int
    decision_hashes: list[str]


class HealthResponse(BaseModel):
    status: str
    engine_version: str
    spacy_available: bool
    sentence_transformers_available: bool
    timestamp: datetime


# ─────────────────────────────────────────────
# APP
# ─────────────────────────────────────────────

app = FastAPI(
    title="FlowGuard — Obligation Priority Engine",
    description=(
        "Deterministic cash flow prioritisation for Indian MSMEs.\n\n"
        "**Architecture**:\n"
        "- Engine (scorer.py) is pure math — no LLM, no randomness.\n"
        "- NLP layer (parser.py) converts human text ↔ engine data.\n"
        "- `/pipeline` is the single entry point for WhatsApp bots.\n\n"
        "**Recommended NLP stack**: spaCy + sentence-transformers.\n"
        "See `/health` to confirm which libraries are loaded."
    ),
    version=ENGINE_VERSION,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Lock down in production
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def _store_audit(result: EngineResult) -> None:
    _audit_store.store(result.run_id, {
        "run_id":           result.run_id,
        "input_hash":       hashlib.sha256(
            json.dumps([d.input_hash for d in result.decisions], sort_keys=True).encode()
        ).hexdigest()[:16],
        "computed_at":      result.computed_at.isoformat(),
        "obligation_count": len(result.decisions),
        "decision_hashes":  [d.input_hash for d in result.decisions],
    })


def _parse_raw_to_score_request(req: NLPParseRequest) -> ScoreRequest:
    """Convert NLPParseRequest → ScoreRequest (shared by /parse and /pipeline)."""
    ref = date.today()
    obligation_dicts, cash_inr = parse_text_to_obligations(req.raw_text, ref)

    if not obligation_dicts:
        raise HTTPException(
            status_code=422,
            detail="Could not extract any obligations from the provided text. "
                   "Try: 'GST 20000 due friday, rent 25000 due 5th, cash 60000'",
        )

    # Validate each obligation dict through Pydantic
    obligations: list[Obligation] = []
    parse_errors: list[str] = []
    for i, ob_dict in enumerate(obligation_dicts):
        try:
            obligations.append(Obligation(**ob_dict))
        except Exception as e:
            parse_errors.append(f"Segment {i+1}: {str(e)[:120]}")

    if not obligations:
        raise HTTPException(
            status_code=422,
            detail=f"All segments failed validation: {parse_errors}"
        )

    if parse_errors:
        logger.warning("Partial parse errors: %s", parse_errors)

    cash_position = CashPosition(
        available_cash_inr=cash_inr if cash_inr > 0 else 0.0,
        as_of_date=ref,
        cash_is_verified=False,  # text input = self-reported, not bank-verified
    )

    return ScoreRequest(
        obligations=obligations,
        cash_position=cash_position,
    )


def _build_delta_narrative(
    original: EngineResult,
    modified: EngineResult,
    params: dict,
) -> str:
    """Plain English comparison of two engine runs."""
    lines = [
        f"If {params.get('counterparty', 'your customer')} pays "
        f"₹{params.get('inflow_amount', 0):,.0f} in {params.get('inflow_day_offset', '?')} day(s):"
    ]
    orig_shortfall = original.cash_shortfall_inr
    new_shortfall  = modified.cash_shortfall_inr

    if new_shortfall < orig_shortfall:
        lines.append(
            f"✅ Shortfall drops from ₹{orig_shortfall:,.0f} to ₹{new_shortfall:,.0f}."
        )
    if original.days_to_zero and not modified.days_to_zero:
        lines.append("✅ Cash no longer runs out in the next 30 days.")
    elif modified.days_to_zero and modified.days_to_zero > (original.days_to_zero or 0):
        lines.append(
            f"✅ Days-to-zero improves from {original.days_to_zero} to {modified.days_to_zero} days."
        )

    # Check if any action changed
    orig_map = {d.obligation_id: d.action for d in original.decisions}
    for d in modified.decisions:
        orig_action = orig_map.get(d.obligation_id)
        if orig_action and orig_action != d.action:
            lines.append(
                f"🔄 {d.counterparty_name}: action changes from "
                f"{orig_action.value} → {d.action.value}."
            )

    if len(lines) == 1:
        lines.append("No material change in payment priority order.")

    return "\n".join(lines)


# ─────────────────────────────────────────────
# ENDPOINTS
# ─────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["Meta"])
async def health():
    """Check engine status and NLP library availability."""
    return HealthResponse(
        status="ok",
        engine_version=ENGINE_VERSION,
        spacy_available=SPACY_AVAILABLE,
        sentence_transformers_available=ST_AVAILABLE,
        timestamp=datetime.utcnow(),
    )


@app.post(
    "/parse",
    response_model=ScoreRequest,
    tags=["NLP"],
    summary="Human text → structured ScoreRequest",
    description=(
        "**INPUT**: Raw human text (English / Hinglish / Tamil-English mix).\n\n"
        "**OUTPUT**: A `ScoreRequest` with validated `Obligation` objects and `CashPosition`.\n\n"
        "This is the parsing-only endpoint. To go all the way to a decision, use `/pipeline`.\n\n"
        "**Example input**:\n"
        "```\n"
        "GST 20000 due Friday, rent 25000 due 5th, supplier payment 80000 by Thursday. "
        "My cash is 1 lakh.\n"
        "```"
    ),
)
async def parse(req: NLPParseRequest) -> ScoreRequest:
    return _parse_raw_to_score_request(req)


@app.post(
    "/score",
    response_model=EngineResult,
    tags=["Engine"],
    summary="Structured obligations → scored decisions",
    description=(
        "**INPUT**: `ScoreRequest` with fully-structured `Obligation` objects.\n\n"
        "**OUTPUT**: `EngineResult` with ranked `DecisionRecord` list, "
        "Days-to-Zero, and shortfall.\n\n"
        "**DETERMINISTIC**: Same input always produces identical output.\n\n"
        "The narrative fields (`summary_narrative`, `whatsapp_summary`) are "
        "populated in this endpoint — no separate narrate call needed "
        "if you already have structured data."
    ),
)
async def score(req: ScoreRequest) -> EngineResult:
    try:
        result = run_engine(
            obligations=req.obligations,
            cash_position=req.cash_position,
            scenario_label=req.scenario_label,
        )
        result.summary_narrative  = narrate_result(result, channel="web")
        result.whatsapp_summary   = narrate_whatsapp_preview(result)
        _store_audit(result)
        return result
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post(
    "/narrate",
    response_model=NarrateResponse,
    tags=["NLP"],
    summary="EngineResult → human-readable text",
    description=(
        "**INPUT**: An `EngineResult` (from `/score`) + output preferences.\n\n"
        "**OUTPUT**: Formatted narrative text.\n\n"
        "- `channel='whatsapp'` — emoji-rich, bullet points, under 300-char preview\n"
        "- `channel='web'`      — full markdown with COT and sub-scores\n"
        "- `channel='voice'`    — TTS-friendly, no emoji, flowing sentences\n\n"
        "Language codes: `en`, `hi`, `ta`, `te`  (non-English is partial in v1.0)"
    ),
)
async def narrate(req: NLPNarrateRequest) -> NarrateResponse:
    text    = narrate_result(req.engine_result, channel=req.channel, language=req.output_language)
    preview = narrate_whatsapp_preview(req.engine_result)
    return NarrateResponse(text=text, whatsapp_preview=preview)


@app.post(
    "/pipeline",
    response_model=PipelineResponse,
    tags=["WhatsApp Bot"],
    summary="ONE-SHOT: Human text → full narrated decisions",
    description=(
        "**This is the primary endpoint for WhatsApp bots.**\n\n"
        "**INPUT**: `NLPParseRequest` — the raw WhatsApp message text.\n\n"
        "**OUTPUT**: `PipelineResponse` with:\n"
        "- `intent` — what the user was asking for\n"
        "- `score_request` — the structured data extracted\n"
        "- `engine_result` — the full deterministic decision set\n"
        "- `narrative` — human-readable text to send back to WhatsApp\n"
        "- `whatsapp_preview` — under-300-char preview\n\n"
        "**Example WhatsApp input**:\n"
        "```\n"
        "gst 20k friday rent 25k monday supplier 80k thursday cash 1 lakh\n"
        "```\n\n"
        "The WhatsApp bot should POST this text here and send back `narrative`."
    ),
)
async def pipeline(req: NLPParseRequest) -> PipelineResponse:
    # Step 1: classify intent
    intent = classify_intent(req.raw_text)

    # Step 2: parse to ScoreRequest
    score_req = _parse_raw_to_score_request(req)

    # Step 3: run engine
    result = run_engine(
        obligations=score_req.obligations,
        cash_position=score_req.cash_position,
    )

    # Step 4: narrate
    channel   = "whatsapp"
    narrative = narrate_result(result, channel=channel, language=req.language)
    preview   = narrate_whatsapp_preview(result)

    result.summary_narrative = narrative
    result.whatsapp_summary  = preview
    _store_audit(result)

    return PipelineResponse(
        intent=intent,
        score_request=score_req,
        engine_result=result,
        narrative=narrative,
        whatsapp_preview=preview,
    )


@app.post(
    "/email",
    response_model=EmailResponse,
    tags=["NLP"],
    summary="Draft a negotiation email for a deferred obligation",
    description=(
        "**INPUT**: An `engine_result`, the index of the decision to draft for, "
        "sender name, and optional proposed payment date.\n\n"
        "**OUTPUT**: Subject line + email body (tone set by relationship_score).\n\n"
        "Tone bands:\n"
        "- relationship 80-100 → Warm & apologetic\n"
        "- relationship 40-79  → Professional & neutral\n"
        "- relationship 0-39   → Firm & brief\n\n"
        "**Note**: The engine decides the tone.  The NLP layer writes the prose."
    ),
)
async def email(req: EmailRequest) -> EmailResponse:
    decisions = req.engine_result.decisions
    if req.decision_index < 0 or req.decision_index >= len(decisions):
        raise HTTPException(
            status_code=422,
            detail=f"decision_index {req.decision_index} out of range "
                   f"(0–{len(decisions)-1}).",
        )
    d    = decisions[req.decision_index]
    body = draft_negotiation_email(d, req.sender_name, req.proposed_date)
    subject = (
        f"Payment Rescheduling — {d.counterparty_name} — "
        f"₹{d.amount_inr:,.0f}"
    )
    return EmailResponse(subject=subject, body=body, tone=d.email_tone.value)


@app.post(
    "/whatif",
    response_model=WhatIfResponse,
    tags=["Engine"],
    summary="Scenario analysis: what if I receive an extra inflow?",
    description=(
        "**INPUT**: A base `ScoreRequest` + a natural-language what-if question.\n\n"
        "**OUTPUT**: Original result, modified result, and a delta narrative.\n\n"
        "The what-if question is parsed to extract:\n"
        "- `inflow_amount` — how much cash arrives\n"
        "- `inflow_day_offset` — when it arrives (days from today)\n"
        "- `counterparty` — who is paying\n\n"
        "The engine then re-runs with the updated `expected_inflows` "
        "and returns both results for comparison.\n\n"
        "**Example**: `'What if Kapoor pays me 30000 tomorrow?'`"
    ),
)
async def whatif(req: WhatIfRequest) -> WhatIfResponse:
    # Run original
    original = run_engine(
        obligations=req.base_score_request.obligations,
        cash_position=req.base_score_request.cash_position,
    )

    # Extract what-if params
    params = extract_what_if_params(req.what_if_text)
    if params["inflow_amount"] <= 0:
        raise HTTPException(
            status_code=422,
            detail="Could not extract an inflow amount from the what-if text.",
        )

    # Build modified cash position
    modified_cash = req.base_score_request.cash_position.model_copy(deep=True)
    day_key = str(params["inflow_day_offset"])
    existing = modified_cash.expected_inflows.get(day_key, 0.0)
    modified_cash.expected_inflows[day_key] = existing + params["inflow_amount"]

    # Re-run engine
    modified = run_engine(
        obligations=req.base_score_request.obligations,
        cash_position=modified_cash,
    )

    delta = _build_delta_narrative(original, modified, params)
    _store_audit(original)
    _store_audit(modified)

    return WhatIfResponse(
        what_if_text=req.what_if_text,
        extracted_params=params,
        original_result=original,
        modified_result=modified,
        delta_narrative=delta,
    )


@app.get(
    "/audit/{run_id}",
    response_model=AuditEntry,
    tags=["Audit"],
    summary="Retrieve the audit trail for a past run",
    description=(
        "Every `/score`, `/pipeline`, and `/whatif` call stores an audit entry.\n\n"
        "The `input_hash` is a SHA-256 of the obligation inputs — "
        "allows judges to verify the same input always produces the same output.\n\n"
        "In production, replace the in-memory store with SQLite or PostgreSQL."
    ),
)
async def audit(run_id: str) -> AuditEntry:
    entry = _audit_store.get(run_id)
    if not entry:
        raise HTTPException(status_code=404, detail=f"Run ID '{run_id}' not found.")
    return AuditEntry(**entry)


@app.get("/audit", response_model=list[str], tags=["Audit"])
async def list_audits():
    """List all run IDs in the audit store."""
    return _audit_store.list_ids()


# ─────────────────────────────────────────────
# UI — CHAT INTERFACE
# ─────────────────────────────────────────────

@app.get("/chat", include_in_schema=False)
async def chat_ui():
    """Serve the FlowGuard chat UI."""
    chat_path = _PROJECT_ROOT / "chat.html"
    if not chat_path.exists():
        raise HTTPException(status_code=404, detail="chat.html not found.")
    return FileResponse(str(chat_path), media_type="text/html")


# ─────────────────────────────────────────────
# GLOBAL ERROR HANDLER
# ─────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_error_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error on %s", request.url)
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_server_error",
            "detail": str(exc),
            "hint":   "Check server logs for full traceback.",
        },
    )
