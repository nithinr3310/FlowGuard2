"""
flowguard/engine/scorer.py
──────────────────────────
The deterministic Consequence Score engine.

IRON RULE: No LLM, no randomness, no network calls.
Same inputs → identical outputs, every run.

Formula (3 steps):
  Step 1  blended = clamp(0.25·P + 0.25·U + 0.25·L + 0.15·C + 0.10·R − 0.08·F, 0, 1)
  Step 2  pre_floor_cs = type_ceiling(category) × blended × 100
  Step 3  cs = max(pre_floor_cs, domain_floor(category))

Edge cases handled:
  • due_date in the past        → urgency = 1.0 (treat as overdue)
  • zero cash                   → all actions default to NEGOTIATE / ESCALATE
  • cascading failures          → contagion computed from graph traversal
  • identical CS ties           → tie-broken by amount DESC (bigger bill first)
  • GST / statutory < 24 h     → score pinned to 95 minimum (CRITICAL band)
  • amount > 10× available cash → confidence penalty applied
  • max_deferral_days = 0       → flexibility forced to FIXED regardless of input
"""

from __future__ import annotations

import hashlib
import json
import logging
import uuid
from datetime import date, datetime
from typing import Optional

from .models import (
    ActionTag,
    CashPosition,
    DecisionRecord,
    EmailTone,
    EngineResult,
    FlexibilityLevel,
    Obligation,
    ObligationCategory,
    ScoreBand,
    SubScores,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# CONSTANTS  (calibrated for Indian MSME context)
# ─────────────────────────────────────────────

# Step 2 — type ceilings
TYPE_CEILING: dict[ObligationCategory, float] = {
    ObligationCategory.STATUTORY:    1.00,
    ObligationCategory.SECURED_LOAN: 0.95,
    ObligationCategory.SALARY:       0.90,
    ObligationCategory.RENT:         0.80,
    ObligationCategory.UTILITY:      0.75,
    ObligationCategory.TRADE_PAYABLE: 0.60,
    ObligationCategory.OTHER:        0.40,
}

# Step 3 — domain floors (law, not math)
DOMAIN_FLOOR: dict[ObligationCategory, float] = {
    ObligationCategory.STATUTORY:    40.0,  # always HIGH band
    ObligationCategory.SECURED_LOAN: 35.0,
    ObligationCategory.SALARY:       35.0,  # Labour Court risk
    ObligationCategory.RENT:         20.0,
    ObligationCategory.UTILITY:      10.0,
    ObligationCategory.TRADE_PAYABLE: 5.0,
    ObligationCategory.OTHER:         0.0,
}

# Edge: statutory obligation due within 24 hours → pin CS ≥ 95
STATUTORY_URGENT_FLOOR = 95.0
STATUTORY_URGENT_HOURS = 24

# Flexibility multipliers (doc spec §Moat1, also Step 1 F-weight)
FLEXIBILITY_DISCOUNT: dict[FlexibilityLevel, float] = {
    FlexibilityLevel.FIXED:       0.0,   # no discount — already immovable
    FlexibilityLevel.NEGOTIABLE:  0.5,   # partial discount
    FlexibilityLevel.DEFERRABLE:  1.0,   # full discount
}

# Sub-score weights
W_P, W_U, W_L, W_C, W_R, W_F = 0.25, 0.25, 0.25, 0.15, 0.10, 0.08

# Score band thresholds
BANDS = [(70, ScoreBand.CRITICAL), (40, ScoreBand.HIGH),
         (21, ScoreBand.MEDIUM),   (0,  ScoreBand.LOW)]

# Email tone thresholds
EMAIL_THRESHOLDS = [(80, EmailTone.WARM_APOLOGETIC),
                    (40, EmailTone.PROFESSIONAL_NEUTRAL),
                    (0,  EmailTone.FIRM_BRIEF)]

# Penalty score cap for normalisation (₹5 lakh)
PENALTY_CAP_INR = 500_000

# Urgency: full score when due today, linear decay to 0 at 90 days
URGENCY_ZERO_DAYS = 90


# ─────────────────────────────────────────────
# SUB-SCORE CALCULATORS
# ─────────────────────────────────────────────

def _penalty_score(ob: Obligation, today: date) -> float:
    """
    P ∈ [0, 1].
    Penalty in absolute ₹ if deferred to max_deferral_days.
    Normalised against PENALTY_CAP_INR.

    Edge: if max_deferral_days == 0, penalty is the per-day rate × 1 day
          (captures the "it's due today" scenario).
    """
    defer_days = max(ob.max_deferral_days, 1)
    daily_penalty = (ob.amount_inr * ob.penalty_rate_annual_pct / 100) / 365
    total_penalty = daily_penalty * defer_days
    # Also consider: penalty could equal the principal (e.g. 100% surcharge)
    # Cap at the full obligation amount as well
    total_penalty = min(total_penalty, ob.amount_inr)
    return min(total_penalty / PENALTY_CAP_INR, 1.0)


def _urgency_score(ob: Obligation, today: date) -> float:
    """
    U ∈ [0, 1].
    1 if due today or overdue.  Linear decay to 0 at URGENCY_ZERO_DAYS.

    Edge: if due_date < today (overdue) → U = 1.0 always.
    """
    days_left = (ob.due_date - today).days
    if days_left <= 0:
        return 1.0
    return max(0.0, 1.0 - days_left / URGENCY_ZERO_DAYS)


def _legal_score(ob: Obligation) -> float:
    """
    L ∈ [0, 1].
    Binary + graded by category.

    STATUTORY:    1.0  (criminal prosecution possible — GST, TDS, PF)
    SECURED_LOAN: 0.6  (civil suit, NPA, SARFAESI action)
    SALARY:       0.5  (Labour Court, ID Act)
    RENT:         0.3  (eviction — civil)
    UTILITY:      0.1  (service disconnection only)
    TRADE_PAYABLE: 0.05 (MSME SAMADHAAN possible but rarely pursued)
    OTHER:        0.0
    """
    legal_map = {
        ObligationCategory.STATUTORY:    1.00,
        ObligationCategory.SECURED_LOAN: 0.60,
        ObligationCategory.SALARY:       0.50,
        ObligationCategory.RENT:         0.30,
        ObligationCategory.UTILITY:      0.10,
        ObligationCategory.TRADE_PAYABLE: 0.05,
        ObligationCategory.OTHER:        0.00,
    }
    return legal_map[ob.category]


def _contagion_score(
    ob: Obligation,
    all_obligations: list[Obligation],
    total_cash: float,
) -> float:
    """
    C ∈ [0, 1].
    Fraction of REMAINING obligations that would also fail if THIS one
    is not paid (cascade graph traversal).

    Special case: STATUTORY / SECURED_LOAN non-payment can trigger a
    bank-account freeze → ALL obligations become unpayable → C = 1.0.

    Edge: single-obligation scenario → C = 0.0 (no cascade possible).
    """
    if len(all_obligations) <= 1:
        return 0.0

    # Hard cascade: bank account freeze risk
    if ob.category in (ObligationCategory.STATUTORY, ObligationCategory.SECURED_LOAN):
        if ob.amount_inr > total_cash * 0.6:
            # Missing a large statutory payment when cash is tight → freeze risk
            return 0.85

    # Graph traversal: follow blocks_other_obligation_ids
    id_to_ob = {o.obligation_id: o for o in all_obligations}
    blocked_ids: set[str] = set()
    frontier = list(ob.blocks_other_obligation_ids)
    while frontier:
        nxt = frontier.pop()
        if nxt in blocked_ids or nxt not in id_to_ob:
            continue
        blocked_ids.add(nxt)
        frontier.extend(id_to_ob[nxt].blocks_other_obligation_ids)

    other_count = len(all_obligations) - 1
    if other_count == 0:
        return 0.0
    return min(len(blocked_ids) / other_count, 1.0)


def _relationship_score_normalised(ob: Obligation) -> float:
    """R ∈ [0, 1].  relationship_score is already [0, 100] → divide by 100."""
    return ob.relationship_score / 100.0


def _flexibility_score(ob: Obligation) -> float:
    """
    F ∈ [0, 1].  The DISCOUNT factor.

    Edge: if max_deferral_days == 0, flexibility is forced to FIXED
          regardless of what the user said.  Can't defer what's already due.
    """
    if ob.max_deferral_days == 0:
        return FLEXIBILITY_DISCOUNT[FlexibilityLevel.FIXED]
    return FLEXIBILITY_DISCOUNT[ob.flexibility]


# ─────────────────────────────────────────────
# CORE FORMULA
# ─────────────────────────────────────────────

def _clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def _score_band(cs: float) -> ScoreBand:
    for threshold, band in BANDS:
        if cs >= threshold:
            return band
    return ScoreBand.LOW


def _email_tone(relationship_score: float) -> EmailTone:
    for threshold, tone in EMAIL_THRESHOLDS:
        if relationship_score >= threshold:
            return tone
    return EmailTone.FIRM_BRIEF


def compute_consequence_score(
    ob: Obligation,
    all_obligations: list[Obligation],
    cash_position: CashPosition,
) -> tuple[float, SubScores]:
    """
    Returns (final_cs, sub_scores).

    Step 1: blended sub-score
    Step 2: multiply by type_ceiling
    Step 3: apply domain floor
    Step 3b: statutory urgent pin (< 24 h due)
    """
    today = cash_position.as_of_date

    P = _penalty_score(ob, today)
    U = _urgency_score(ob, today)
    L = _legal_score(ob)
    C = _contagion_score(ob, all_obligations, cash_position.available_cash_inr)
    R = _relationship_score_normalised(ob)
    F = _flexibility_score(ob)

    blended = _clamp(W_P * P + W_U * U + W_L * L + W_C * C + W_R * R - W_F * F)
    ceiling = TYPE_CEILING[ob.category]
    pre_floor_cs = ceiling * blended * 100

    # Step 3: domain floor
    floor = DOMAIN_FLOOR[ob.category]
    cs = max(pre_floor_cs, floor)

    # Edge: statutory + due within 24 h → hard pin
    if ob.category == ObligationCategory.STATUTORY:
        hours_left = (ob.due_date - today).days * 24
        if hours_left <= STATUTORY_URGENT_HOURS:
            cs = max(cs, STATUTORY_URGENT_FLOOR)

    cs = _clamp(cs, 0.0, 100.0)

    sub_scores = SubScores(
        P=round(P, 4), U=round(U, 4), L=round(L, 4),
        C=round(C, 4), R=round(R, 4), F=round(F, 4),
        blended=round(blended, 4),
        type_ceiling=ceiling,
    )
    return round(cs, 2), sub_scores


# ─────────────────────────────────────────────
# CONSTRAINT SOLVER  (greedy, deterministic)
# ─────────────────────────────────────────────

def _days_to_zero(
    cash: float,
    inflows: dict[str, float],
    outflows_by_day: dict[int, float],
) -> tuple[Optional[int], Optional[float]]:
    """
    Project forward 30 days.
    Returns (crisis_day, deficit_amount) or (None, None) if solvent.
    inflows keys are string day-offsets from cash_position.as_of_date.
    """
    running = cash
    for day in range(1, 31):
        running += inflows.get(str(day), 0.0)
        running -= outflows_by_day.get(day, 0.0)
        if running < 0:
            return day, round(running, 2)
    return None, None


def _compute_daily_outflows(decisions: list[DecisionRecord], today: date) -> dict[int, float]:
    outflows: dict[int, float] = {}
    for d in decisions:
        if d.action == ActionTag.PAY and d.action_date:
            offset = (d.action_date - today).days
            if 0 < offset <= 30:
                outflows[offset] = outflows.get(offset, 0.0) + d.amount_inr
    return outflows


def _confidence(
    ob: Obligation,
    cs: float,
    sub_scores: SubScores,
    cash_coverage: float,   # available_cash / amount
) -> tuple[float, list[str]]:
    """
    Confidence ∈ [0, 1].  Penalised by:
    • estimated (not verified) penalty rate
    • very low cash coverage (paying this empties the tank)
    • low urgency score (far-future deadline → less certain)
    """
    base = 0.85
    basis: list[str] = []

    if ob.penalty_rate_annual_pct > 0:
        basis.append(f"penalty_rate_{ob.penalty_rate_annual_pct:.0f}pct_annual")
    else:
        base -= 0.05
        basis.append("penalty_rate_not_provided")

    if cash_coverage < 1.2:
        base -= 0.08
        basis.append("cash_covers_barely_over_obligation")
    if cash_coverage < 0.5:
        base -= 0.07
        basis.append("cash_insufficient_for_obligation")

    if sub_scores.U < 0.3:
        base -= 0.05
        basis.append("low_urgency_far_deadline")

    if ob.relationship_score >= 80:
        basis.append(f"relationship_score_{ob.relationship_score:.0f}_strong")

    return round(_clamp(base), 3), basis


# ─────────────────────────────────────────────
# COT  (chain-of-thought — keys for NLP layer)
# ─────────────────────────────────────────────

def _build_cot(
    ob: Obligation,
    cs: float,
    sub_scores: SubScores,
    action: ActionTag,
    action_date: Optional[date],
    penalty_per_day: float,
) -> dict[str, str]:
    """
    Returns the 4-part COT as plain English strings.
    These are ALREADY human-readable — the NLP layer can pass them
    through unchanged or rephrase them for the output channel.
    """
    band = _score_band(cs)
    days_left = (ob.due_date - date.today()).days if ob.due_date else "?"

    act = f"{action.value} ₹{ob.amount_inr:,.0f} to {ob.counterparty_name}"
    if action_date:
        act += f" by {action_date.strftime('%d %b %Y')}"

    reason_parts = []
    if sub_scores.L >= 0.5:
        reason_parts.append("carries legal / criminal risk")
    if sub_scores.U >= 0.8:
        reason_parts.append(f"due in {days_left} day(s)")
    if sub_scores.P >= 0.5:
        reason_parts.append(f"daily penalty ₹{penalty_per_day:,.0f}")
    if not reason_parts:
        reason_parts.append(f"Consequence Score {cs:.1f} ({band.value})")
    reason = f"Consequence Score {cs:.1f} ({band.value}) — " + ", ".join(reason_parts) + "."

    tradeoff = (
        f"Deferring by 1 day costs ₹{penalty_per_day:,.0f}."
        if penalty_per_day > 0
        else "No direct financial penalty for deferral, but relationship risk applies."
    )

    downstream = (
        "Paying this frees remaining cash for lower-priority obligations."
        if action == ActionTag.PAY
        else f"Deferring to {action_date} allows cash to be used for higher-priority payments first."
    )

    return {
        "cot_action":     act,
        "cot_reason":     reason,
        "cot_tradeoff":   tradeoff,
        "cot_downstream": downstream,
    }


def _input_hash(ob: Obligation) -> str:
    payload = json.dumps({
        "id":     ob.obligation_id,
        "amount": ob.amount_inr,
        "due":    ob.due_date.isoformat(),
        "cat":    ob.category.value,
    }, sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()[:12]


# ─────────────────────────────────────────────
# PUBLIC API
# ─────────────────────────────────────────────

def run_engine(
    obligations: list[Obligation],
    cash_position: CashPosition,
    scenario_label: Optional[str] = None,
) -> EngineResult:
    """
    Main entry point.  Takes obligations + cash, returns EngineResult.

    Pure deterministic — no I/O, no LLM.  Call from the API layer.
    """
    if not obligations:
        raise ValueError("obligations list is empty.")

    today = cash_position.as_of_date
    available = cash_position.available_cash_inr
    total_owed = sum(o.amount_inr for o in obligations)
    shortfall = max(0.0, total_owed - available)

    # ── Step A: score every obligation ────────
    scored: list[tuple[float, SubScores, Obligation]] = []
    for ob in obligations:
        cs, subs = compute_consequence_score(ob, obligations, cash_position)
        scored.append((cs, subs, ob))

    # ── Step B: sort DESC by CS, tie-break by amount DESC ─────
    scored.sort(key=lambda x: (x[0], x[2].amount_inr), reverse=True)

    # ── Step C: greedy allocation ──────────────
    remaining_cash = available
    decisions: list[DecisionRecord] = []

    for cs, subs, ob in scored:
        penalty_per_day = (ob.amount_inr * ob.penalty_rate_annual_pct / 100) / 365
        penalty_if_deferred = penalty_per_day * max(ob.max_deferral_days, 1)

        # Determine action
        if remaining_cash >= ob.amount_inr:
            action = ActionTag.PAY
            allocated = ob.amount_inr
            remaining_cash -= allocated
            action_date = today  # pay now
        elif ob.category == ObligationCategory.STATUTORY and ob.max_deferral_days == 0:
            # Cannot defer a statutory obligation due today with no cash → ESCALATE
            action = ActionTag.ESCALATE
            allocated = 0.0
            action_date = today
        elif ob.flexibility == FlexibilityLevel.FIXED:
            action = ActionTag.ESCALATE
            allocated = 0.0
            action_date = today
        elif ob.flexibility == FlexibilityLevel.NEGOTIABLE:
            action = ActionTag.NEGOTIATE
            allocated = 0.0
            # Suggest deferral to when next inflow covers it
            action_date = None
        else:
            action = ActionTag.DEFER
            allocated = 0.0
            action_date = None

        cash_coverage = available / ob.amount_inr if ob.amount_inr > 0 else 99.0
        confidence, basis = _confidence(ob, cs, subs, cash_coverage)

        cot = _build_cot(ob, cs, subs, action, action_date, penalty_per_day)

        decisions.append(DecisionRecord(
            obligation_id=ob.obligation_id,
            obligation_description=ob.description,
            counterparty_name=ob.counterparty_name,
            amount_inr=ob.amount_inr,
            due_date=ob.due_date,
            consequence_score=cs,
            score_band=_score_band(cs),
            sub_scores=subs,
            action=action,
            action_date=action_date,
            cash_allocated_inr=allocated,
            penalty_per_day_inr=round(penalty_per_day, 2),
            penalty_if_deferred_full_inr=round(penalty_if_deferred, 2),
            reasoning_key=f"{action.value.lower()}_{ob.category.value.lower()}_cs{int(cs)}",
            confidence=confidence,
            confidence_basis=basis,
            email_tone=_email_tone(ob.relationship_score),
            input_hash=_input_hash(ob),
            **cot,
        ))

    # ── Step D: days-to-zero projection ───────
    daily_outflows = _compute_daily_outflows(decisions, today)
    crisis_day, deficit = _days_to_zero(
        available, cash_position.expected_inflows, daily_outflows
    )

    return EngineResult(
        run_id=str(uuid.uuid4())[:8],
        as_of_date=today,
        available_cash_inr=available,
        total_obligations_inr=round(total_owed, 2),
        cash_shortfall_inr=round(shortfall, 2),
        decisions=decisions,
        days_to_zero=crisis_day,
        deficit_on_crisis_day_inr=deficit,
    )
